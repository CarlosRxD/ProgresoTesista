class BorradorTesis {
    constructor(urlArchivo, autor, fecha) {
        this.urlArchivo = urlArchivo;
        this.autor = autor;
        this.fecha = fecha;
    }

    enviarBorrador() {
        
        return true;
    }
}
export default BorradorTesis;