import Tarea from './Tarea.js';
import ListaTareas from './ListaTareas.js';


var lista = new ListaTareas;
$(document).ready(function () {
    //limpiarLocalStorage();
    //cargarLocalStorage();
    cargarTareasDesdeLocalStorage();

    $('#guardarDatos').click(function () {
        agregarTarea();

    });

});

function cargarTareasDesdeLocalStorage() {
    let cadenaArray = localStorage.getItem("lista");
    if (cadenaArray != null) {
        lista = JSON.parse(cadenaArray);
        cargarTareas();
    }
}
function agregarTarea() {
    let actividad = $('#actividad_input').val();
    let estado = $('#estado_input').val();
    let fechaLimite = $('#fecha_limite_input').val();
    let id = Math.floor(Math.random() * 100) + 1;
    while (verificarIdExistente(id)) {
        id = Math.floor(Math.random() * 100) + 1;
    }
    let tarea = new Tarea(id, actividad, estado, fechaLimite);
    lista._elementos.push(tarea);
    localStorage.setItem("lista", JSON.stringify(lista));
}
function verificarIdExistente(nuevoId) {
    for (let i = 0; i < lista.length; i++) {
        if (lista._elementos[i].id === nuevoId) {
            return true;
        }
    }
    return false;
}
function cargarLocalStorage() {

    lista.agregarElemento(new Tarea(1, "Cambiar Título de Tesis", "Completo", "4/17/2024"));
    lista.agregarElemento(new Tarea(2, "Preparar Presentación", "Pendiente", "4/20/2024"));
    lista.agregarElemento(new Tarea(3, "Investigar Bibliografía", "En Progreso", "4/22/2024"));
    lista.agregarElemento(new Tarea(4, "Escribir Resumen", "Pendiente", "4/25/2024"));
    lista.agregarElemento(new Tarea(5, "Revisar Referencias", "En Progreso", "4/28/2024"));

    localStorage.setItem("lista", JSON.stringify(lista));

}
function limpiarLocalStorage() {
    localStorage.clear();
}
function cargarTareas() {
    let elementos = lista._elementos;

    for (let i = 0; i < elementos.length; i++) {
        let tarea = elementos[i];
        elementos[i] = new Tarea(tarea._id, tarea._actividad, tarea._estado, tarea._fecha);

        mostrarTareas(elementos[i]);
    }
}
function mostrarTareas(item) {
    let ids = item.id;

    $("#listaTareas").append(`
                <tr id="${ids}">
                    <th>${item.actividad}</th>
                    <td>${item.estado}</td>
                    <td>${item.fecha}</td>
                    <td><button id="btn${ids}" class="btn btn-outline-danger">Eliminar</button></td>
                </tr>
            `);
    $("#btn" + ids).attr("indice", ids);
    $("#btn" + ids).click(function () {
        let indice = $("#" + this.id).attr("indice");
        lista._elementos.splice(indice - 1, 1);
        localStorage.setItem("lista", JSON.stringify(lista));
        $(`#${ids}`).remove();
        
    });
}
